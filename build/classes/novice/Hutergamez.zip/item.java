package novice;

public class item {
   public int gold;
   public String name_item;
   public int hp_potion;
   public int limititem;
   public item(){
   
}
public void describe_items(){
    System.out.println("-------------------------------------");
    System.out.println("Description Item");
    System.out.println("-------------------------------------");
    System.out.println("Hp potion : increase HP");
    System.out.println("DarkSword : Attack 50 damage");
    System.out.println("Armor : protect your body");
}
//public void 

}
